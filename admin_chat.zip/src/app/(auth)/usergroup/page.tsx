export default function UserGroup() {
  return (
    <div>
      faq
    </div>
  );
}
