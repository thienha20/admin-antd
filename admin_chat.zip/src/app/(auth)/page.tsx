'use client';

export default function Home() {
  return (
    <div>
      noi dung test
    </div>
  );
}
