export interface User {
  userId?: bigint;
  first_name?: string;
  last_name?: string;
  email?: string;
  phone?: string;
}