'use client';

import { SettingDrawer } from '@ant-design/pro-layout';

export default SettingDrawer;