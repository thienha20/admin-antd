export default function Subscribe() {
  return (
    <div>
      faq
    </div>
  );
}
