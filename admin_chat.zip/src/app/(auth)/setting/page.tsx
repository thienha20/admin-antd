export default function Setting() {
  return (
    <div>
      faq
    </div>
  );
}
