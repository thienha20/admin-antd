export default function User() {
  return (
    <div>
      faq
    </div>
  );
}
