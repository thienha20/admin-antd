export default function Dashboard() {
  return (
    <div>
      faq
    </div>
  );
}
