'use client';

// import ProLayout from '@ant-design/pro-layout';
import { DashboardOutlined, FormOutlined, UserOutlined } from '@ant-design/icons';
// import { Avatar } from "antd";
import Link from 'next/link';
import React, { useState } from 'react';
import dynamic from 'next/dynamic';

const DynamicSettingDrawer = dynamic(() => import('./SettingDrawerClient'), {
  ssr: false,
});
const DynamicProLayout = dynamic(() => import('./ProLayoutClient'), {
  ssr: false,
});

const menuData = [
  {
    path: '/',
    name: 'Dashboard',
    icon: <DashboardOutlined/>,
    routes: [
      {
        path: '/',
        name: 'Analysis',
      },
      {
        path: '/monitor',
        name: 'Monitor',
      },
    ],
  },
  {
    path: '/form',
    name: 'Form',
    icon: <FormOutlined/>,
    routes: [
      {
        path: '/faq',
        name: 'Basic Form',
      },
    ],
  },
  {
    path: '/profile',
    name: 'Account',
    icon: <UserOutlined/>,
  },
];

export default function ProLayoutWrapper({children}: { children: React.ReactNode }) {
  const [settings, setSettings] = useState({});
  return (
    <>
      <DynamicProLayout
        {...settings}
        title="CMS Chat Bot AI"
        logo="https://cdn.jsdelivr.net/gh/ant-design/ant-design-pro@master/public/logo.svg"
        layout="mix"
        fixSiderbar
        location={{
          pathname: '/',
        }}
        avatarProps={{
          src: 'https://xsgames.co/randomusers/avatar.php?g=male',
          title: 'Serati Ma',
          size: 'small',
        }}
        menuItemRender={(item, dom) =>
          item.path ? <Link href={item.path}>{dom}</Link> : dom
        }
        route={{
          path: '/',
          routes: menuData,
        }}
      >
        <div style={{padding: 24, background: '#f5f5f5'}}>
          {children}
        </div>
      </DynamicProLayout>
      {process.env.NEXT_PUBLIC_APP_ENV === 'development' && <DynamicSettingDrawer
        pathname="/"
        enableDarkTheme
        settings={settings}
        onSettingChange={(newSettings) => setSettings(newSettings)}
        getContainer={false} // nếu không dùng portal
        disableUrlParams={true}
      />}
    </>
  );
}
