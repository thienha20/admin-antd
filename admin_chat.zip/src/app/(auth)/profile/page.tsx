export default function Profile() {
  return (
    <div>
      faq
    </div>
  );
}
