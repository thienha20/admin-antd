'use client';

import { Roboto } from 'next/font/google';
import './globals.css';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { getQueryClient } from '@/utils/get-query-client';
import StoreProvider from '@/app/contexts/StoreProvider';
import React from 'react';
import ProLayoutWrapper from '@/components/layout/ProLayoutWrapper';
import { AntdRegistry } from '@ant-design/nextjs-registry';
import NextTopLoader from 'nextjs-toploader';

const roboto = Roboto({weight: ['400', '500', '700', '900'], subsets: ['vietnamese'], display: 'swap'});

export default function RootLayout({
                                     children,
                                   }: Readonly<{
  children: React.ReactNode;
}>) {
  return (
      <StoreProvider>
        <html lang="en">
        <body suppressHydrationWarning={true} className={`${roboto.className}`}>
        <NextTopLoader color="#6273FF"
                       initialPosition={0.08}
                       crawlSpeed={200}
                       height={3}
                       crawl={true}
                       showSpinner={true}
                       easing="ease"
                       speed={200}
                       shadow="0 0 10px #6273FF,0 0 5px #6273FF"
                       template='<div class="bar" role="bar"><div class="peg"></div></div>
      <div class="spinner" role="spinner"><div class="spinner-icon"></div></div>'
                       zIndex={1600}
                       showAtBottom={false}/>
        <AntdRegistry>
          <QueryClientProvider client={getQueryClient()}>
            <ProLayoutWrapper>
              {children}
              {process.env.NEXT_PUBLIC_APP_ENV === 'development' && <ReactQueryDevtools/>}
            </ProLayoutWrapper>
          </QueryClientProvider>
        </AntdRegistry>
        </body>
        </html>
      </StoreProvider>
  );
}
