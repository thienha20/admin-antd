export default function ProfileChangePassword() {
  return (
    <div>
      faq
    </div>
  );
}
