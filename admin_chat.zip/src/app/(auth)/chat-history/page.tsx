export default function ChatHistory() {
  return (
    <div>
      faq
    </div>
  );
}
