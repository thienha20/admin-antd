'use client';
export default function Faq() {
  return (
    <div>
      faq
    </div>
  );
}
