export interface UserGroup {
  userGroupId?: number;
  name?: string;
  description?: string;
  groupType?: string;
}