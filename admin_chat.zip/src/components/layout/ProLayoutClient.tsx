'use client';

import Layout from '@ant-design/pro-layout';

export default Layout;